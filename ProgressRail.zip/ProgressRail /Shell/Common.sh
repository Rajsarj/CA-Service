
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
YELLOW='\033[0;35m'
NC='\033[0m'

#BOOTSTRAP_HOST="localhost"
USER="admin"
PASS="admin"
AUTH_MODE="anyauth"
SEC_REALM="public"
N_RETRY=5
RETRY_INTERVAL=10
HOST=localhost
CLUSTER=""

# Suppress progress meter, but still show errors
CURL="curl -s -S -v -i"
AUTH_CURL="${CURL} --${AUTH_MODE} --user ${USER}:${PASS}"



#######################################################
# restart_check(hostname, baseline_timestamp, caller_lineno)
#
# Use the timestamp service to detect a server restart, given a
# a baseline timestamp. Use N_RETRY and RETRY_INTERVAL to tune
# the test length. Include authentication in the curl command
# so the function works whether or not security is initialized.
#   $1 :  The hostname to test against
#   $2 :  The baseline timestamp
#   $3 :  Invokers LINENO, for improved error reporting
# Returns 0 if restart is detected, exits with an error if not.
#
function restart_check {
  LAST_START=`$AUTH_CURL "http://$1:8001/admin/v1/timestamp"`
  for i in `seq 1 ${N_RETRY}`; do
    if [ "$2" == "$LAST_START" ] || [ "$LAST_START" == "" ]; then
      sleep ${RETRY_INTERVAL}
      LAST_START=`$AUTH_CURL "http://$1:8001/admin/v1/timestamp"`
    else 
      return 0
    fi
  done
  echo "ERROR: Line $3: Failed to restart $1"
  exit 1
}


show_help()
{
    echo -e "${RED} Setup.sh -i MarkLogic.rpm -h BootstrapHost ${NC}"
    echo -e "${RED} Setup.sh -i MarkLogic.rpm -h Host -c ClusterToJoin ${NC}"
    echo -e "${RED} AWSSetup.sh -a AWS_HostNa -K Key  ${NC}"
    echo "     "$# arguments 
    exit 1
}




# A POSIX variable
OPTIND=1         # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
output_file=""
verbose=0

#echo -e "${RED}........WHAT ??? ${NC}"

