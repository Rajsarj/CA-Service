#!/bin/bash
source ./Common.sh

CURL="curl -s -S"
AUTH_CURL="${CURL} --${AUTH_MODE} --user ${USER}:${PASS}"

while getopts "?:v:?:i:h:c:" opt; do
    case $opt in
    \?)
        show_help
        exit 0
        ;;
    v)  CURL="curl -s -S -v -i"	
        ;;
    i)  RPM=$OPTARG
        ;;
    h)  HOST=$OPTARG
	;;
    c)  CLUSTER=$OPTARG
        ;;
    esac
done
shift $((OPTIND-1))
[ "$1" = "--" ] && shift

echo -e  "${RED} RPM=$RPM, HOST=$HOST, CLUSTER=$CLUSTER, Leftovers: $@ ${NC}"


if [ -z "$RPM" ]; 
	then echo -e "\n${RED} RPM location Needed ${NC}";
        exit 0; 
else 
        echo -e "\n${BLUE} Stopping & Removing MarkLogic (if Previously Installed)... '$RPM'${NC}"; 
	sudo /etc/init.d/MarkLogic stop >/dev/null
	sudo rpm -e MarkLogic
	cd /var/opt/; sudo rm -rf MarkLogic; #sudo rm -rf /var/opt/MarkLogic >/dev/null
        cd $HOME;
        echo -e "\n${BLUE} Installing... '$RPM'${NC}"; 
        sudo rpm -ivh  $RPM >/dev/null
	sudo /etc/init.d/MarkLogic start >/dev/null
	sleep 5

	echo -e "\n${YELLOW} .... Init MarkLogic ${NC}";
	TIMESTAMP=`$AUTH_CURL -X POST -d ""  http://$HOST:8001/admin/v1/init | grep "last-startup" | sed 's%^.*<last-startup.*>\(.*\)</last-startup>.*$%\1%'`
	
	echo -e "\n${YELLOW} .... Init TimeStamp [$TIMESTAMP] ${NC}";
	TIMESTAMP=`$AUTH_CURL -X GET http://$HOST:8001/admin/v1/timestamp`
	#echo -e "\n\n${YELLOW}.... Timestamp [$TIMESTAMP] ${NC}"
    sleep 5
fi


echo -e "\n\n${BLUE} BootStrap Host -or- Node Joining Existing Cluster ?${NC}";

if [ -z "$CLUSTER" ]; 
        then 
	if [ -z "$HOST" ]; then echo -e "\n\n${RED} Bootstrap HostName needed!${NC}"; exit 0;
        fi
         
        echo -e "${BLUE} Initiating as Bootstrap Host/New Cluster...${NC}";
        echo -e "${YELLOW} .... Set Username/Password, & Capture ReStart TimeStamp${NC}"

    	TIMESTAMP=`$CURL -X POST \
                -H "Content-type: application/x-www-form-urlencoded" \
                --data "admin-username=${USER}" --data "admin-password=${PASS}" \
                --data "realm=${SEC_REALM}" \
                http://$HOST:8001/admin/v1/instance-admin | grep "last-startup" | sed 's%^.*<last-startup.*>\(.*\)</last-startup>.*$%\1%'`
 	
	echo -e "\n${YELLOW} .... Instance-Admin TimeStamp [$TIMESTAMP] ${NC}"
	if [ "$TIMESTAMP" == "" ]; then
            echo -e "\n\n${RED} ERROR: Failed to get instance-admin TimeStamp. ${NC}" >&2
            exit 1
        fi
	# Test for successful restart
        restart_check localhost $TIMESTAMP $LINENO

        echo -e "\n\n${BLUE} Initialization complete for localhost...${NC}"
else 
        echo -e "\n\n${BLUE} Joining... '$CLUSTER'${NC}"; 
	echo -e "${YELLOW} .... Request Local Server Config${NC}";

        JOINER_CONFIG=`$CURL -X GET -H "Accept: application/xml" \
                http://$HOST:8001/admin/v1/server-config`
                #--data "admin-username=${USER}" --data "admin-password=${PASS}" \
                #--data "realm=${SEC_REALM}" \m
                #--anyauth --user admin:admin
        echo -e "\n\n${YELLOW} .... Local Config : '$JOINER_CONFIG' ${NC}";
        echo -e "\n\n${YELLOW} .... POST Local Config to '$CLUSTER'${NC}";
        $AUTH_CURL -X POST -d "group=Default" \
                --data-urlencode "server-config=${JOINER_CONFIG}" \
                -H "Content-type: application/x-www-form-urlencoded" \
                -o cluster-config.zip http://$CLUSTER:8001/admin/v1/cluster-config

        echo -e "\n\n${YELLOW} .... Cluster Config : 'cat cluster-config.zip'  ${NC}";

        echo -e "\n\n${YELLOW} .... Request Local TimeStamp ${NC}";
        $AUTH_CURL -X GET http://$HOST:8001/admin/v1/timestamp
        echo -e "\n\n${YELLOW} .... Timestamp [$TIMESTAMP] ${NC}"

        echo -e "\n\n${YELLOW} .... POST Cluster Config to LocalHost${NC}";
        $AUTH_CURL -X POST -H "Content-type: application/zip" \
                --data-binary @./cluster-config.zip \
                http://$HOST:8001/admin/v1/cluster-config

	echo -e "\n\n${BLUE} Cluster Join complete for $HOST...to $CLUSTER ${NC}"
fi


