#!/bin/bash
my_dir="$(dirname "$0")"


RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
YELLOW='\033[0;35m'
NC='\033[0m'

#BOOTSTRAP_HOST="localhost"
USER="admin"
PASS="admin"
AUTH_MODE="anyauth"
SEC_REALM="public"
N_RETRY=5
RETRY_INTERVAL=10

AWS=18.223.211.237
CLUSTER=""

# Suppress progress meter, but still show errors
CURL="curl -s -S -v -i"
AUTH_CURL="${CURL} --${AUTH_MODE} --user ${USER}:${PASS}"

show_help()
{
    echo -e "${RED} AWSSetup.sh -a AWS_Host ${NC}"
    echo "     "$# arguments 
    exit 1
}

CURL="curl -s -S"
AUTH_CURL="${CURL} --${AUTH_MODE} --user ${USER}:${PASS}"

while getopts "h?:r:a:k:" opt; do
    case $opt in
    h|\?)
        show_help
        exit 0
        ;;
    a)  AWS=$OPTARG
        ;;

    esac
done
shift $((OPTIND-1))
[ "$1" = "--" ] && shift

echo -e  "${YELLOW} AWS Instance=$AWS,   Leftovers: $@ ${NC}"



################################################################
################# Create REST Apps 80/81 #######################
################################################################
echo -e "${YELLOW} ..... Create REST API Instance on Port 8080  ${NC}";
$AUTH_CURL -X POST --header "Content-Type:application/json" \
  -d '{"rest-api": { "name": "FamilyTreeApp", "port": "8080", "database": "FamilyTreeDB", "modules-database": "FamilyTreeModulesDB", "forests-per-host": 1 } }' \
   http://$AWS:8002/v1/rest-apis 

sleep 2

echo -e "${YELLOW} ..... Create REST API Instance on Port 8081 ${NC}";
$AUTH_CURL -X POST --header "Content-Type:application/json" \
  -d '{"rest-api": { "name": "FamilyTreeModuleApp", "port": "8081", "database": "FamilyTreeModulesDB", "modules-database": "Modules" } }' \
   http://$AWS:8002/v1/rest-apis
   

echo -e "${YELLOW} ..... Create REST API Instance on Port 8082 ${NC}";
$AUTH_CURL -X POST --header "Content-Type:application/json" \
  -d '{ "server-name": "WebDAV-FamilyTreeModuleApp3", "root" : "/", "port": "8083", "content-database": "FamilyTreeModulesDB" }' \
   'http://18.223.211.237:8002/manage/v2/servers?group-id=Default&server-type=webdav'
    

sleep 2

################################################################
###################### Import Modules  #########################
##################   Change MLCP Path      #####################
################################################################
./mlcp-10.0.4.2/bin/mlcp.sh IMPORT \
-host $AWS  \
-port 8081 -username $USER -password $PASS \
-output_uri_replace "$(pwd)/import/modules,''"  \
-input_file_path import/modules/

################################################################
###################### Import Data  ############################
################################################################
echo -e "${YELLOW} ..... Load Triples to Content DB attached to Port 8080 ${NC}";
$AUTH_CURL -X PUT --header "Content-Type: application/xml"  --data-binary @./import/data/AvinashTest.xml  "http://$AWS:8080/v1/documents?uri=/AvinashTest.xml"

$AUTH_CURL -X PUT --header "Content-type: application/n-triples" \
--data-binary @./import/data/triples/SPARQL-Megha.ttl    "http://$AWS:8080/v1/graphs?default"  

################################################################
###########           Lauch Browser                #############
################################################################
sleep 5
echo -e "${YELLOW} ..... Launch Web Browser ${NC}";
#open http://$AWS:8080

