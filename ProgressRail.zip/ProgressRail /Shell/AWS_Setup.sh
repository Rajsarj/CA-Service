#!/bin/bash
my_dir="$(dirname "$0")"


RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
YELLOW='\033[0;35m'
NC='\033[0m'

#BOOTSTRAP_HOST="localhost"
USER="admin"
PASS="admin"
AUTH_MODE="anyauth"
SEC_REALM="public"
N_RETRY=5
RETRY_INTERVAL=10
HOST=localhost
CLUSTER=""

# Suppress progress meter, but still show errors
CURL="curl -s -S -v -i"
AUTH_CURL="${CURL} --${AUTH_MODE} --user ${USER}:${PASS}"

show_help()
{
    echo -e "${RED} AWSSetup.sh -a AWS_HostNa -K Key  ${NC}"
    echo "     "$# arguments 
    exit 1
}

CURL="curl -s -S"
AUTH_CURL="${CURL} --${AUTH_MODE} --user ${USER}:${PASS}"

while getopts "h?:r:a:k:" opt; do
    case $opt in
    h|\?)
        show_help
        exit 0
        ;;
    r)  RPM=$OPTARG 
        ;;
    a)  AWS=$OPTARG
        ;;
    k)  KEY=$OPTARG
        ;;
    esac
done
shift $((OPTIND-1))
[ "$1" = "--" ] && shift

echo -e  "${YELLOW} AWS Instance=$AWS, MarkLogic Version=$RPM, Key/Cert=$KEY, Leftovers: $@ ${NC}"


if [ -z ${AWS+x} ]; 
  then echo -e "${RED} AWS Instance needed ${NC}";
             echo -e "${RED} Example - ${BLUE}./AWS_Copy.sh -a ec2-34-203-218-209.compute-1.amazonaws.com -k Avinash_Amazon.pem -r MarkLogic-9.0-4.1.x86_64.rpm ${NC}";
             echo -e "${RED} ...... Starting MarkLogic without Installing ... Gradle Init. ${NC}";
        #exit 0; 
fi

if [ -z ${KEY+x} ];
        then echo -e "${RED} AWS Certificate/Key needed ${NC}";
        echo -e "${RED} Example - ${BLUE}./AWS_Copy.sh -a ec2-34-203-218-209.compute-1.amazonaws.com -k Avinash_Amazon.pem -r MarkLogic-9.0-4.1.x86_64.rpm ${NC}";
        exit 0; 
fi

if [ -z ${RPM+x} ];
        then echo -e "${RED} MarkLogic Version needed ${NC}";
        echo -e "${RED} Example - ${BLUE}./AWS_Copy.sh -a ec2-34-203-218-209.compute-1.amazonaws.com -k Avinash_Amazon.pem -r MarkLogic-9.0-4.1.x86_64.rpm ${NC}";
        exit 0;
fi


echo -e "${YELLOW} ..... Copy Startup.sh and MarkLogic rpm to AWS Instance  ${NC}";
sudo chown 600 $KEY

################################################################
################ Copy MarkLogic RPM ############################
################################################################
# Copy Profile File to AWS Linux
if [ -z ${AWS+x} ]; 
    then echo -e "${RED} ...... Download MarkLogic RPM Manually ${NC}";
else
    scp -i $KEY bash_profile.ft ec2-user@$AWS:/home/ec2-user/
    ssh -i $KEY ec2-user@$AWS 'cat bash_profile.ft >> .bash_profile'
    ssh -i $KEY ec2-user@$AWS 'sudo mkdir /Sonu'
    ssh -i $KEY ec2-user@$AWS 'sudo chmod o+w /Sonu/'
    scp -i $KEY  $RPM  ec2-user@$AWS:/home/ec2-user/
fi


################################################################
########## Change Hardcoded HostName in JavaScript #############
################################################################
#if [ -z ${AWS+x} ]; then 
    echo -e "${RED} ==> Update EndPoint in Profile.MarkLogic.js Manually <==${NC}";
#else
#    echo -e "${RED} ..... Updating Endpoint in Profile.js ${NC}";
    #awk '{gsub(/localhost/,"'$AWS'")}1' ./import/modules/js/Profile.FamilyTree.js > ./import/modules/js/Profile.FamilyTree.js 
    #cp ./import/modules/js/Profile.FamilyTree.js profile.original
    #awk '{gsub(/localhost/,"'$AWS'")}1' ./import/modules/js/Profile.FamilyTree.js  > temp_$AWS.txt 
    #cp temp_$AWS.txt  > ./import/modules/js/Profile.FamilyTree.js 
#fi    




################################################################
################ To Install Gradle on MacOS ####################
################   UnComment Below Lines    ####################
################################################################
#/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
#brew install gradle;



################################################################
################ Install MarkLogic #############################
################################################################
if [ -z ${AWS+x} ]; 
    then echo -e "${RED} ...... Clean-Install MarkLogic Manually ${NC}";
else

    if type gradle; 
    then

        echo -e "${YELLOW} ..... Yum Install GDB, Glibc & Java on AWS  ${NC}";
        ssh -i $KEY ec2-user@$AWS 'sudo yum install lsb -y >/dev/null; sudo yum install gdb -y >/dev/null; sudo yum install glibc.i686 -y >/dev/null; sudo yum install java -y >/dev/null; ‘sudo yum install libnsl -y >/dev/null

        echo -e "\n${BLUE} UnInstalling... '$RPM'${NC}"; 
        ssh -i $KEY ec2-user@$AWS 'sudo /etc/init.d/MarkLogic stop >/dev/null; sudo rpm -e MarkLogic; cd /var/opt/; sudo rm -rf MarkLogic;'
        echo -e "\n${BLUE} ...Installing... '$RPM'${NC}"; 
        ssh -i $KEY ec2-user@$AWS 'cd $HOME; sudo rpm -ivh  '$RPM' >/dev/null; sudo /etc/init.d/MarkLogic start >/dev/null'

        echo "mlHost=${AWS}" > gradle.properties
        echo "mlUsername=${USER}" >> gradle.properties
        echo "mlPassword=${PASS}" >> gradle.properties
        echo "plugins { id \"com.marklogic.ml-gradle\" version \"3.4.0\" }" > build.gradle 
        gradle mlInit; gradle mlInstallAdmin;
        rm -rf gradle.properties build.gradle
    else 
        echo "Gradle Not Found..... Initialize ML Manually !"
        scp -i $KEY  Startup.sh ec2-user@$AWS:/home/ec2-user/
        scp -i $KEY  Common.sh  ec2-user@$AWS:/home/ec2-user/
        ssh -i $KEY             ec2-user@$AWS 'chmod 700 Startup.sh; ./Startup.sh -i ' $VER ' -h '$AWS
    fi
fi



################################################################
################# Create REST Apps 80/81 #######################
################################################################
echo -e "${YELLOW} ..... Create REST API Instance on Port 80  ${NC}";
$AUTH_CURL -X POST --header "Content-Type:application/json" \
  -d '{"rest-api": { "name": "FamilyTreeApp", "port": "80", "database": "FamilyTreeDB", "modules-database": "FamilyTreeModulesDB", "forests-per-host": 1 } }' \
   http://$AWS:8002/v1/rest-apis 

sleep 2

echo -e "${YELLOW} ..... Create REST API Instance on Port 81 ${NC}";
$AUTH_CURL -X POST --header "Content-Type:application/json" \
  -d '{"rest-api": { "name": "FamilyTreeModuleApp", "port": "81", "database": "FamilyTreeModulesDB", "modules-database": "Modules" } }' \
   http://$AWS:8002/v1/rest-apis 

sleep 2

################################################################
###################### Import Modules  #########################
##################   Change MLCP Path      #####################
################################################################
./mlcp-9.0.4/bin/mlcp.sh IMPORT \
-host $AWS  \
-port 81 -username $USER -password $PASS \
-output_uri_replace "$(pwd)/import/modules,''"  \
-input_file_path import/modules/

################################################################
########### Change Authentication & Add Range Index  ###########
################################################################
$AUTH_CURL http://$AWS:80/query/SetAppAuthentication.xqy
$AUTH_CURL http://$AWS:80/query/AddRangeIndex.xqy

################################################################
###################### Import Data  ############################
################################################################
echo -e "${YELLOW} ..... Load Triples to Content DB attached to Port 80 ${NC}";
$AUTH_CURL -X PUT --header "Content-Type: application/xml"  --data-binary @./import/data/AvinashTest.xml  "http://$AWS:80/v1/documents?uri=/AvinashTest.xml"

$AUTH_CURL -X PUT --header "Content-type: application/n-triples" \
--data-binary @./import/data/triples/SPARQL.ttl    "http://$AWS:80/v1/graphs?default"  

################################################################
###########           Lauch Browser                #############
################################################################
sleep 5
echo -e "${YELLOW} ..... Launch Web Browser ${NC}";
open http://$AWS

