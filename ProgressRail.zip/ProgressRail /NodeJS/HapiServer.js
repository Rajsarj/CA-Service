'use strict';

const Hapi = require('hapi');
const HapiSwagger = require('hapi-swagger');
const Inert = require('inert');
const Joi = require('joi');
const Request = require('request');
const Vision = require('vision');
const config = require('config');

const fs = require('fs');

const server = new Hapi.Server();
var serverConfig = config.get('Server');
server.connection({ port: 8080 });


const options = 
{
    info: {
        'title': 'CA-Service API Documentation',
        'version': '0.0.3',
    }
};

server.register([Inert,
                Vision,
                {
                    'register': HapiSwagger,
                    'options': options
                }], 
                (err) => 
                {

                    if (err) 
                    {
                        throw err;
                    }

                    server.start(
                        (err) => 
                        {

                            if (err) 
                            {
                            throw err;
                            }
                            console.log(`Server running at: ${server.info.uri}`);
                        })

                });
  		
server.route({
    method: 'GET',
    path: '/ca_service',
    config: 
    {
        description: "GET CA Service, Retrieval of Cert ID",
        notes: "Some notes",
        tags: ['api'],
        validate: 
        {
            query: 
            {
                requester: Joi.string(),
                duration: Joi.number()
            }
        },
        handler: function (request, reply) 
        {
            console.log('=======GET=========')
            var payload = request.payload
            console.log(payload)

            console.log(request.query.requester);
            console.log(`Requester : ${request.query.requester}`);
            console.log(`Duration : ${request.query.duration}`);


            reply('GET Done ['+payload +']');
        }
    }
});

server.route({
    method: 'POST',
    path: '/enroll',
    config: 
    {
        description: "POST CA Service for Enrollment",
        notes: "Some notes",
        tags: ['api'],
        validate: 
        {
            query: 
            {
                requester: Joi.string(),
                duration: Joi.number(),
                serialNumber: Joi.number()
            }
        },
        handler: function (request, reply) 
        {
            console.log('=======POST=========')

            var payload = request.payload
            var csrFile = 'Cert.csr'

            console.log(payload);
            console.log(JSON.stringify(payload));

            console.log(`Requester : ${request.query.requester}`);
            console.log(`Duration : ${request.query.duration}`);


            fs.writeFileSync(csrFile, payload);

            console.log('.... child process...');
            const exec  = require('child_process').execSync;
          
            
            //exec("awk 'NF {sub(/\r/, \"\"); printf \"%s\\n\",$0;}' /Code/Cert/ML.pem", (error, stdout, stderr) =>
            //var myResult = exec("ls -alt /Code/", (error, stdout, stderr) =>
            exec(`openssl x509 -req -days ${request.query.duration} -in ${csrFile} -CA /Code/RootCA/CA.pem -CAkey /Code/RootCA/CA.key -set_serial ${request.query.serialNumber} -out Cert.pem`);

            var myFile;
            const exec2  = require('child_process').execSync;
            var myResult = exec2("cat Cert.pem");

            //myResult.stdout
            console.log(`Output [${myResult}]`)

            
            reply(myResult);
        }
    }
});

