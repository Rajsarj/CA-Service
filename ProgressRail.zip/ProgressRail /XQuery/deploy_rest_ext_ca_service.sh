curl -X PUT --anyauth --user admin:admin  --data-binary @./ca_service.xqy \
    -H "Content-type: application/xquery"  \
    http://$PR:80/LATEST/config/resources/ca_service -v


