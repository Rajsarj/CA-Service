curl -X POST --anyauth --user admin:admin -d @"./rest_config.xml" \
    -H "Content-type: application/xml" \
    http://$PR:8002/v1/rest-apis -v
